# --------------------------SCRAPE THE DATA---------------------------

# import the appropriate libararies
# pandas for importing the data into a dataframe
import pandas as pd
# requests and beautiful soup for accessing the website
import requests
from bs4 import BeautifulSoup
# numpy for math operations
import numpy as np

# starting source
infile = 'Player_List.csv'

# import the source data into a dataframe
player_source = pd.read_csv(infile)
# print(player_source)

# force the columns to string
player_source[['Player_Name', 'Position', 'Url']] = player_source[['Player_Name', 'Position', 'Url']].astype(str)

# columns and dataframe for the scrape
URLs = player_source['Url']
Players = player_source['Player_Name']
Positions = player_source['Position']
new_df = []

# URL, Player, and Position to build the function with
BUILD_URL_b = URLs[0]
Player_b = Players[0]
Position_b = Positions[0]

# pulls in the URL
page_b = requests.get(BUILD_URL_b)

# create space to put the data
tbl_data_1_b = []
tbl_headers_1_b = []
new_df_b = []
new_df_hdr_b = []

# The HTTP 200 OK success status response code indicates that the request has succeeded.
if page_b.status_code == 200:
    # print("IN PARSE")
    # html parser
    soup_b = BeautifulSoup(page_b.text, 'html.parser')
    # find all tables on the webpage
    tables_b = soup_b.find_all('table')
    # find the tables listed as pgl_basic (where the game data is stored)
    table_b = soup_b.find('table', id='pgl_basic')
    # print(table)
    # Skip the header, may need to change?
    for row_b in table_b.find_all('tr')[1:]:
        # print(row)
        tds_b = row_b.find_all('td')
        new_row_b = 'N'
        table_head_b = 'newrow'
        table_data_b = 'YES'
        for td_b in tds_b:
            # table headers
            tbl_headers_b = td_b['data-stat']
            tbl_data_b = td_b.text
            if tbl_headers_b == 'game_season':
                new_row_b = "Y"
            else:
                new_row_b = "N"

            if new_row_b == "Y":
                if not tbl_data_1_b:
                    table_data_b = 'NO'
                else:
                    new_df_b.append(tbl_data_1_b)
                    new_df_hdr_b.append(tbl_headers_1_b)
                    col_heads_b = (tbl_headers_1_b)
                tbl_headers_1_b = []
                tbl_data_1_b = []
                new_row_b = "N"
                if td_b.text == '':
                    table_data_b = 'NO'
                else:
                    table_data_b = 'YES'

            if table_data_b == 'YES':
                tbl_data_1_b.append(tbl_data_b)
                tbl_headers_1_b.append(tbl_headers_b)
    if not tbl_data_1_b:
        table_data_b = 'NO'
    else:
        new_df_b.append(tbl_data_1_b)
        new_df_hdr_b.append(tbl_headers_1_b)
        col_heads_b = (tbl_headers_1_b)

    df_new_b = pd.DataFrame(new_df_b, columns=col_heads_b)
    df_new_b['Name'] = Player_b
    df_new_b['Position'] = Position_b


# Function for scrape
def NBA_Scrape(i, dfnew_b):
    # URL, Player, and Position to build the function with
    BUILD_URL = URLs[i]
    Player = Players[i]
    Position = Positions[i]

    # pulls in the URL
    page = requests.get(BUILD_URL)

    # create space to put the data
    tbl_data_1 = []
    tbl_headers_1 = []
    new_df = []
    new_df_hdr = []

    # The HTTP 200 OK success status response code indicates that the request has succeeded.
    if page.status_code == 200:
        # print("IN PARSE")
        # html parser
        soup = BeautifulSoup(page.text, 'html.parser')
        # find all tables on the webpage
        tables = soup.find_all('table')
        # find the tables listed as pgl_basic (where the game data is stored)
        table = soup.find('table', id='pgl_basic')
        # print(table)
        # Skip the header, may need to change?
        for row in table.find_all('tr')[1:]:
            # print(row)
            tds = row.find_all('td')
            new_row = 'N'
            thead = 'newrow'
            tdata = 'YES'
            for td in tds:
                # table headers
                tbl_headers = td['data-stat']
                tbl_data = td.text
                if tbl_headers == 'game_season':
                    new_row = "Y"
                else:
                    new_row = "N"

                if new_row == "Y":
                    if not tbl_data_1:
                        tdata = 'NO'
                    else:
                        new_df.append(tbl_data_1)
                        new_df_hdr.append(tbl_headers_1)
                        col_heads = (tbl_headers_1)
                    tbl_headers_1 = []
                    tbl_data_1 = []
                    new_row = "N"
                    if td.text == '':
                        tdata = 'NO'
                    else:
                        tdata = 'YES'

                if tdata == 'YES':
                    tbl_data_1.append(tbl_data)
                    tbl_headers_1.append(tbl_headers)
        if not tbl_data_1:
            tdata = 'NO'
        else:
            new_df.append(tbl_data_1)
            new_df_hdr.append(tbl_headers_1)
            col_heads = (tbl_headers_1)

        df_new = pd.DataFrame(new_df, columns=col_heads)
        df_new['Name'] = Player
        df_new['Position'] = Position
        # print(dfnew)

        df_new_b = dfnew_b.append(df_new, ignore_index=True)

    return (df_new_b)


# iterate the scrape across the whole pop
players_indexes = np.arange(1, len(player_source))
# print(players_indexes)
for i in players_indexes:
    df_new_b = NBA_Scrape(i, df_new_b)

print(df_new_b)

#create a CSV file to store the data for analytics
player_data_csv = df_new_b.to_csv('Player_Data.csv', encoding='utf-8', index=False)
player_data_csv