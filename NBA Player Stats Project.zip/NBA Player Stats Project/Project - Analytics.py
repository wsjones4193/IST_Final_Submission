# --------------------------ANALYTICS---------------------------

#import the appropriate libararies

#pandas for importing the data into a dataframe
import pandas as pd
#numpy to do math on the dataframes
import numpy as np
#matplot to do visualizations
import matplotlib as mp
#seaborn to do visualizations
import seaborn as sb

#import the data from the Player_Data.csv
Player_Data = pd.read_csv('Player_Data.csv')

#select which group to analyze
pos = input("\nWhat position are you analyzing? You must enter one of the following:\n"
            "\nBall Dominant Guard"
            "\nPassing Guard"
            "\nScoring Guard"
            "\nRole Player Guard"
            "\nScoring Wing"
            "\nRole Player Wing"
            "\nStretch Big"
            "\nRole Player"
            "\nCenter\n"
            "\nFYI This is CaSe SeNsItIve")
analysis_pop = Player_Data[Player_Data.Position == pos]

#select which stat to analyze
stat = input("\nWhat statistic are you analyzing? You must enter one of the following:\n"
            "\nfg,fga,fg3,fg3a,ft,fta,orb,drb,trb,ast,stl,blk,tov,pts")
analysis_stat = analysis_pop[stat]

#to numpy array as float
stat_array = analysis_stat.astype(np.float64)

#select the betting line
line = input("\nWhat is the betting line (ie. 20 pts, 8 rebs, etc.)?"
             "\nOnly enter the number:")
line = float(line)

# ----- HIT RATE CALCULATION -----

print('\nHit Rate %\n')

#hit rate calculation
def hit_rate(i):
    denominator = len(stat_array)
    numerator = stat_array[stat_array > (line + i)]
    num_len = len(numerator)
    hit_rate = num_len/denominator
    print(line + i,'=',hit_rate)

#iterate the hit rate across similar lines
stat_range = np.arange(-3, 4)
for i in stat_range:
    hit_rate(i)

# ----- SUMMARY STATISTICS AND VISUALIZATIONS OF THE GROUP -----

grp_min = np.min(stat_array)
print('\nGrouping Minimum\n', grp_min)
grp_25 = np.percentile(stat_array,25)
print('Grouping 1st Quartile\n', grp_25)
grp_mean = round(np.mean(stat_array),2)
print('Grouping Mean\n',grp_mean)
grp_75 = np.percentile(stat_array,75)
print('Grouping 3rd Quartile\n', grp_75)
grp_max = np.max(stat_array)
print('Grouping Maximum\n',grp_max)

plot1 = sb.boxplot(x=stat_array)
plot2 = sb.displot(x=stat_array, binwidth = 2)